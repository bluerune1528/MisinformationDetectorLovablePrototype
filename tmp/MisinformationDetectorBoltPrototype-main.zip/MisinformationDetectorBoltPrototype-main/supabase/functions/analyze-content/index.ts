import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalysisRequest {
  text?: string;
  url?: string;
}

interface HFResponse {
  sequence?: string;
  scores?: number[];
  labels?: string[];
}

async function extractTextFromUrl(url: string): Promise<string> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch URL: ${response.status}`);
    }

    const html = await response.text();
    const textMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    const bodyText = textMatch ? textMatch[1] : html;

    const cleanText = bodyText
      .replace(/<[^>]*>/g, " ")
      .replace(/\s+/g, " ")
      .replace(/&nbsp;/g, " ")
      .trim();

    return cleanText.substring(0, 2000);
  } catch (err) {
    console.error("URL extraction error:", err);
    throw new Error("Could not extract content from URL");
  }
}

function calculateCredibilityScore(text: string, hfScore?: number): number {
  let score = 50;

  const uppercaseWords = (text.match(/[A-Z]+/g) || []).length;
  const uppercaseRatio = uppercaseWords / (text.split(/\s+/).length || 1);
  if (uppercaseRatio > 0.3) score -= 10;

  const exclamationCount = (text.match(/!/g) || []).length;
  const questionCount = (text.match(/\?/g) || []).length;
  const emotionalRatio = (exclamationCount + questionCount) / (text.length / 100);
  if (emotionalRatio > 0.5) score -= 8;

  const urlCount = (text.match(/https?:\/\//g) || []).length;
  if (urlCount > 0) score += 10;

  const quotationMarks = (text.match(/["']/g) || []).length;
  if (quotationMarks >= 2) score += 5;

  const numbers = (text.match(/\d+/g) || []).length;
  if (numbers > 0) score += 5;

  const suspicious = [
    "you won't believe",
    "shocking",
    "doctors hate",
    "this one trick",
    "big pharma",
    "wake up sheeple",
  ];

  for (const phrase of suspicious) {
    if (text.toLowerCase().includes(phrase)) {
      score -= 15;
    }
  }

  if (hfScore !== undefined) {
    score = Math.round((score + hfScore) / 2);
  }

  return Math.max(0, Math.min(100, score));
}

function generateFlags(text: string): string[] {
  const flags: string[] = [];

  if ((text.match(/!/g) || []).length > text.length / 50) {
    flags.push("Excessive exclamation marks detected");
  }

  if (text.toUpperCase() === text && text.length > 20) {
    flags.push("Text in all caps - potential sensationalism");
  }

  const emotionalWords = [
    "outrageous",
    "unbelievable",
    "shocking",
    "disgusting",
    "evil",
  ];
  const hasEmotional = emotionalWords.some((word) =>
    text.toLowerCase().includes(word)
  );
  if (hasEmotional) {
    flags.push("Strong emotional language detected");
  }

  if (!text.includes(".") && text.length > 100) {
    flags.push("No proper punctuation - low credibility");
  }

  if ((text.match(/\b(fake|hoax|conspiracy)\b/i) || []).length > 0) {
    flags.push("Conspiracy-related keywords detected");
  }

  return flags.slice(0, 3);
}

function extractDomainAuthority(url: string): number {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname || "";

    const trustedDomains = [
      "bbc.com",
      "reuters.com",
      "apnews.com",
      "npr.org",
      "wikipedia.org",
      "nature.com",
      "science.org",
      "arxiv.org",
    ];

    const unreliableDomains = [
      "infowars.com",
      "naturalnews.com",
      "beforeitsnews.com",
    ];

    if (unreliableDomains.some((d) => domain.includes(d))) {
      return 20;
    }

    if (trustedDomains.some((d) => domain.includes(d))) {
      return 85;
    }

    const hasHttps = urlObj.protocol === "https:";
    const baseScore = hasHttps ? 55 : 40;

    return baseScore;
  } catch {
    return 40;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { text, url } = (await req.json()) as AnalysisRequest;

    if (!text && !url) {
      return new Response(
        JSON.stringify({ error: "Please provide text or URL" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    let contentToAnalyze = text;
    let sourceAuthority: number | undefined;

    if (url) {
      contentToAnalyze = await extractTextFromUrl(url);
      sourceAuthority = extractDomainAuthority(url);
    }

    const flags = generateFlags(contentToAnalyze || "");
    const credibilityScore = calculateCredibilityScore(contentToAnalyze || "");

    const reasoning =
      credibilityScore >= 70
        ? "This content appears credible based on the language used, structure, and lack of common misinformation indicators."
        : credibilityScore >= 40
          ? "This content has mixed credibility signals. Some aspects are reasonable, but there are warning signs that warrant verification through other sources."
          : "This content shows multiple indicators commonly found in misinformation. We strongly recommend verifying claims through trusted sources before sharing.";

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (supabaseUrl && supabaseKey) {
      const insertResponse = await fetch(
        `${supabaseUrl}/rest/v1/analyses`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: supabaseKey,
            Authorization: `Bearer ${supabaseKey}`,
          },
          body: JSON.stringify({
            text_input: text || null,
            url_input: url || null,
            extracted_text: url ? contentToAnalyze : null,
            credibility_score: credibilityScore,
            reasoning,
            flags,
            source_authority: sourceAuthority || null,
          }),
        }
      );

      if (!insertResponse.ok) {
        console.error("Failed to save analysis:", await insertResponse.text());
      } else {
        const savedAnalysis = await insertResponse.json();
        const analysisId = savedAnalysis[0]?.id || "unknown";

        return new Response(
          JSON.stringify({
            credibilityScore,
            reasoning,
            flags,
            sourceAuthority,
            analysisId,
          }),
          {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }
    }

    return new Response(
      JSON.stringify({
        credibilityScore,
        reasoning,
        flags,
        sourceAuthority,
        analysisId: "temp-" + Date.now(),
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (err) {
    console.error("Analysis error:", err);

    return new Response(
      JSON.stringify({
        error:
          err instanceof Error
            ? err.message
            : "An error occurred during analysis",
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

/*
  # Create analyses table for misinformation detection

  1. New Tables
    - `analyses`
      - `id` (uuid, primary key)
      - `text_input` (text, nullable)
      - `url_input` (text, nullable)
      - `extracted_text` (text, nullable) - for URL content
      - `credibility_score` (integer, 0-100)
      - `reasoning` (text) - explanation from AI
      - `flags` (text array) - warning flags
      - `source_authority` (integer, nullable) - for URLs
      - `created_at` (timestamp)

  2. Description
    - Stores all user analysis requests and results
    - No authentication needed - public access
    - Simple schema for college project
*/

CREATE TABLE IF NOT EXISTS analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text_input text,
  url_input text,
  extracted_text text,
  credibility_score integer DEFAULT 50,
  reasoning text DEFAULT '',
  flags text[] DEFAULT '{}',
  source_authority integer,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_analyses_created_at ON analyses(created_at DESC);

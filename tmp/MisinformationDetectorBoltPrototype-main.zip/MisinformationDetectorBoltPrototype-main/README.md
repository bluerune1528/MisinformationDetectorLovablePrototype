# Misinformation Detection Website

A simple, free misinformation detection tool that analyzes text and URLs for credibility and potential misinformation indicators.

## 1. ARCHITECTURE OVERVIEW

### Three-Layer Architecture

**Frontend Layer (React + TypeScript)**
- Single Page Application built with React 18
- Component-based architecture with reusable components
- Real-time UI updates using React hooks
- Responsive design with Tailwind CSS
- No authentication needed - completely public

**Backend Layer (Supabase)**
- PostgreSQL database for storing all analyses
- Supabase Edge Functions (Deno runtime) for serverless processing
- Simple REST API calls to store and retrieve results

**AI Analysis Layer (Pattern Matching + Heuristics)**
- No expensive AI APIs - uses simple pattern matching
- Text analysis algorithms for credibility scoring
- Domain authority checking for URLs
- Flag detection for common misinformation patterns

### Data Flow

```
User Input (Text/URL)
    ↓
React Form (AnalysisForm.tsx)
    ↓
Supabase Edge Function (analyze-content/index.ts)
    ├→ Extract text from URL if needed
    ├→ Calculate credibility score (0-100)
    ├→ Generate warning flags
    ├→ Store in PostgreSQL database
    └→ Return results to frontend
    ↓
Display Results (ResultsDisplay.tsx)
    ↓
View History (AnalysisHistory.tsx)
```

---

## 2. TECHNOLOGIES USED

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool (already configured)
- **React Router DOM** - Page navigation
- **Tailwind CSS** - Styling (already configured)
- **Lucide React** - Icons (already installed)

### Backend
- **Supabase PostgreSQL** - Database
- **Supabase Edge Functions** - Serverless analysis processor
- **Deno Runtime** - JavaScript runtime for edge functions

### Utilities
- Built-in Web APIs (fetch, URL parsing)
- No external AI APIs needed

---

## 3. FOLDER STRUCTURE

```
project/
├── src/
│   ├── components/              # Reusable React components
│   │   ├── AnalysisForm.tsx     # Text/URL input form with tabs
│   │   ├── ResultsDisplay.tsx   # Display analysis results
│   │   ├── AnalysisHistory.tsx  # List of past analyses
│   │   ├── Header.tsx           # Navigation header
│   │   └── LoadingSpinner.tsx   # Loading indicator
│   ├── pages/                   # Page components
│   │   ├── HomePage.tsx         # Main analysis page
│   │   └── HistoryPage.tsx      # View all analyses
│   ├── lib/
│   │   └── supabase.ts          # Supabase client initialization
│   ├── services/
│   │   └── analysisService.ts   # API calls to Edge Function & database
│   ├── types/
│   │   └── index.ts             # TypeScript interfaces
│   ├── utils/
│   │   └── formatters.ts        # Utility functions for formatting
│   ├── App.tsx                  # Main app with routing
│   ├── main.tsx                 # React entry point
│   └── index.css                # Global Tailwind styles
├── supabase/
│   ├── functions/
│   │   └── analyze-content/
│   │       └── index.ts         # Edge Function for analysis
│   └── migrations/
│       └── 001_create_analyses_table.sql  # Database schema
├── package.json
├── vite.config.ts
├── tsconfig.json
└── README.md
```

---

## 4. FRONTEND-BACKEND COMMUNICATION

### Simple HTTP Flow

1. **User submits content** via AnalysisForm component
   - Input validation happens in React component
   - Shows loading state while processing

2. **Call Edge Function** via Supabase client:
   ```typescript
   const { data, error } = await supabase.functions.invoke('analyze-content', {
     body: { text: userInput } // or { url: userInput }
   })
   ```

3. **Edge Function processes request**:
   - Extracts text from URL if provided (uses fetch)
   - Calculates credibility score using heuristics
   - Detects warning flags
   - Saves result to PostgreSQL database
   - Returns structured JSON response

4. **Frontend displays results** in ResultsDisplay component:
   ```typescript
   {
     credibilityScore: 0-100,
     reasoning: "explanation text",
     flags: ["flag1", "flag2"],
     sourceAuthority: 0-100,
     analysisId: "uuid"
   }
   ```

5. **View history** - HistoryPage queries database directly:
   ```typescript
   const { data } = await supabase
     .from('analyses')
     .select('*')
     .order('created_at', { ascending: false })
     .limit(50)
   ```

### API Endpoints
- **POST** `/functions/v1/analyze-content` - Analyze text or URL
- **GET** `/rest/v1/analyses` - Fetch analysis history

---

## 5. AI MODEL INTEGRATION (Simplified Approach)

### Why No Paid APIs?

Instead of expensive OpenAI/Hugging Face APIs, we use **pattern matching and heuristics** that are:
- Completely free
- Always available
- Fast and reliable
- Sufficient for a college project

### Analysis Algorithm

**Text Analysis (0-100 score):**

1. **Base Score**: Start at 50
2. **Language Patterns** (-30 to +30):
   - Excessive caps: -10
   - Too many exclamation marks: -8
   - Suspicious phrases ("you won't believe", "doctors hate", etc.): -15
   - URLs in text: +10
   - Quotation marks (citations): +5
   - Numbers (data/facts): +5

3. **Domain Authority** (for URLs, -40 to +40):
   - Known reliable domains (BBC, Reuters, NPR, Wikipedia): +85
   - Known unreliable domains (InfoWars, NaturalNews): +20
   - HTTPS vs HTTP: +15 or -15
   - Default for unknown: +55

4. **Final Score**: Clamp between 0-100

**Credibility Labels:**
- **70-100**: Likely Credible
- **40-69**: Uncertain (needs verification)
- **0-39**: Likely Misinformation

### Warning Flags Generated

- "Excessive exclamation marks detected"
- "Text in all caps - potential sensationalism"
- "Strong emotional language detected"
- "No proper punctuation - low credibility"
- "Conspiracy-related keywords detected"

### Example: Analyzing a Claim

```
Input: "You won't BELIEVE what doctors don't want you to know!!!"

Processing:
- Base score: 50
- "You won't believe" phrase: -15
- All caps "BELIEVE": -10
- 3 exclamation marks: -8
- Final: 50 - 15 - 10 - 8 = 17

Output:
{
  credibilityScore: 17,
  reasoning: "This content shows multiple indicators commonly found in misinformation...",
  flags: [
    "Excessive exclamation marks detected",
    "Strong emotional language detected",
    "Conspiracy-related keywords detected"
  ]
}
```

### How to Improve This Later

1. Add Hugging Face free API for better classification
2. Use machine learning models (distilBERT for text classification)
3. Add fact-checking API integration
4. Build custom training data from labeled sources
5. Add sentiment analysis

---

## 6. TEAM WORK DIVISION (5 Students)

### Student 1: Frontend UI Components Developer
**Responsibility:** Build all React components

**Tasks:**
- AnalysisForm.tsx - Text/URL input with tabs
- ResultsDisplay.tsx - Show results with color coding
- AnalysisHistory.tsx - Display list of past analyses
- Header.tsx - Navigation bar
- LoadingSpinner.tsx - Loading indicator
- Styling with Tailwind CSS
- Responsive design for mobile

**Deliverables:**
- All components fully styled
- Interactive form validation
- Clean, usable UI

**Timeline:** Days 1-2

---

### Student 2: Frontend Logic & Page Setup
**Responsibility:** Connect components, set up routing, manage state

**Tasks:**
- Set up React Router (routing done ✓)
- HomePage.tsx - Main analysis page
- HistoryPage.tsx - View history page
- Form submission handling
- Loading and error states
- Connect components together

**Deliverables:**
- Working navigation between pages
- Form submission flow
- Error handling UI

**Timeline:** Days 2-3

---

### Student 3: Database & Supabase Configuration
**Responsibility:** Database setup and queries

**Tasks:**
- Set up Supabase project (already done ✓)
- Create database schema (already done ✓)
- Write supabase.ts client initialization (already done ✓)
- Create analysisService.ts for queries (already done ✓)
- Optimize database indexes
- Test database connections
- Write documentation on Supabase setup

**Deliverables:**
- Working Supabase connection
- Database queries working
- Performance optimization

**Timeline:** Days 1-2

---

### Student 4: Edge Function & Analysis Algorithm
**Responsibility:** Backend analysis processing

**Tasks:**
- Create analyze-content Edge Function (already done ✓)
- Implement credibility scoring algorithm (already done ✓)
- URL text extraction logic (already done ✓)
- Warning flag detection (already done ✓)
- Domain authority checking (already done ✓)
- Test with various inputs
- Improve accuracy over time

**Deliverables:**
- Working Edge Function
- Accurate scoring algorithm
- Fast processing (<2 seconds)

**Timeline:** Days 2-4

---

### Student 5: Integration, Testing & Deployment
**Responsibility:** Bring everything together and deploy

**Tasks:**
- Test all components work together
- Test database persistence
- Test Edge Function calls
- Check performance and fix issues
- Write deployment instructions
- Create simple documentation
- Deploy to production (Vercel)
- Handle bugs and edge cases

**Deliverables:**
- Working end-to-end application
- Deployment documentation
- List of remaining improvements

**Timeline:** Days 4-6

---

## Getting Started

### Prerequisites
- Node.js 16+
- npm or yarn
- A Supabase account (free tier)

### Setup Instructions

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment variables** (already in .env):
   ```
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key
   ```

3. **Run development server:**
   ```bash
   npm run dev
   ```
   Opens at `http://localhost:5173`

4. **Build for production:**
   ```bash
   npm run build
   ```

5. **Type checking:**
   ```bash
   npm run typecheck
   ```

---

## Project Features

✅ **Text Analysis** - Check any claim or statement for misinformation
✅ **URL Analysis** - Extract and analyze website content
✅ **Credibility Scoring** - 0-100 score with color-coded results
✅ **Warning Flags** - Detailed indicators of potential misinformation
✅ **Analysis History** - View all past analyses
✅ **No Authentication** - Completely public, no signup needed
✅ **Fast Processing** - Results in seconds
✅ **No Costs** - Free to build and run

---

## Key Files & Their Purpose

| File | Purpose |
|------|---------|
| `src/App.tsx` | Main app component with routing |
| `src/components/AnalysisForm.tsx` | User input form |
| `src/pages/HomePage.tsx` | Main analysis page |
| `src/services/analysisService.ts` | API calls and database queries |
| `supabase/functions/analyze-content/index.ts` | Core analysis algorithm |
| `src/types/index.ts` | TypeScript interfaces |
| `src/utils/formatters.ts` | Helper functions |

---

## Limitations & Future Improvements

### Current Limitations
- Heuristic-based analysis (not AI-powered)
- Limited to text extraction from simple HTML
- No image/video analysis
- No fact-checking database integration
- Limited to English content

### Future Improvements
1. Integrate with Hugging Face free models for better classification
2. Add fact-checking API (ClaimBuster, ClaimBuster, etc.)
3. Implement sentiment analysis
4. Add source credibility database
5. Support image and video analysis
6. Multi-language support
7. User accounts to save favorite analyses
8. Browser extension version

---

## Deployment

### Deploy to Vercel (Recommended for students)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Add environment variables (Supabase URL & Key)
6. Click Deploy
7. Your site is live!

### Deploy to Other Platforms
- Netlify (similar to Vercel)
- GitHub Pages (static hosting)
- Firebase Hosting
- AWS Amplify

---

## Troubleshooting

**Edge Function not working?**
- Check Supabase Edge Functions are deployed: `mcp__supabase__list_edge_functions`
- Check console for errors
- Verify function code is valid

**Database not saving analyses?**
- Check `.env` file has correct Supabase credentials
- Check table exists: `analyses` table in Supabase
- Check database is public (no RLS blocking inserts)

**UI not styling correctly?**
- Run `npm run build` to check for errors
- Clear browser cache
- Check Tailwind CSS is imported in `index.css`

---

## Code Organization Principles

- **Components** - Reusable UI pieces
- **Pages** - Full-page views (HomePage, HistoryPage)
- **Services** - API calls and database queries
- **Types** - TypeScript interfaces and types
- **Utils** - Helper functions (formatters, validators)
- **Lib** - Library initialization (Supabase client)

Keep each file focused on ONE responsibility for easy maintenance!

---

## License

This is a college project. Use freely for educational purposes.

---

Built with ❤️ using React, TypeScript, Supabase, and Tailwind CSS

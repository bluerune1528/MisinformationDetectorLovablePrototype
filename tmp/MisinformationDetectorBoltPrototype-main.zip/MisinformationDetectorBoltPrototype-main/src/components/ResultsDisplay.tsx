import { AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';
import { AnalysisResponse } from '@/types';
import { getCredibilityColor, getCredibilityBgColor } from '@/utils/formatters';

interface ResultsDisplayProps {
  result: AnalysisResponse;
}

export function ResultsDisplay({ result }: ResultsDisplayProps) {
  const scoreColor = getCredibilityColor(result.credibilityScore);
  const bgColor = getCredibilityBgColor(result.credibilityScore);

  const getScoreLabel = () => {
    if (result.credibilityScore >= 70) return 'Likely Credible';
    if (result.credibilityScore >= 40) return 'Uncertain';
    return 'Likely Misinformation';
  };

  const getScoreIcon = () => {
    if (result.credibilityScore >= 70) {
      return <CheckCircle className="w-6 h-6 text-green-600" />;
    }
    if (result.credibilityScore >= 40) {
      return <AlertCircle className="w-6 h-6 text-yellow-600" />;
    }
    return <AlertTriangle className="w-6 h-6 text-red-600" />;
  };

  return (
    <div className={`w-full max-w-2xl mx-auto p-6 border rounded-lg ${bgColor}`}>
      <div className="flex items-start gap-4 mb-6">
        <div>{getScoreIcon()}</div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Analysis Result
          </h3>
          <div className="flex items-baseline gap-2">
            <span className={`text-3xl font-bold ${scoreColor}`}>
              {result.credibilityScore}%
            </span>
            <span className={`text-sm font-medium ${scoreColor}`}>
              {getScoreLabel()}
            </span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-gray-900 mb-3">Analysis Details</h4>
        <p className="text-gray-700 leading-relaxed">{result.reasoning}</p>
      </div>

      {result.flags && result.flags.length > 0 && (
        <div className="mb-6">
          <h4 className="font-semibold text-gray-900 mb-3">Warning Flags</h4>
          <ul className="space-y-2">
            {result.flags.map((flag, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-700">{flag}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.sourceAuthority !== undefined && (
        <div className="pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Source Authority Score: <span className="font-semibold">{result.sourceAuthority}%</span>
          </p>
        </div>
      )}

      <p className="text-xs text-gray-500 mt-4">
        Analysis ID: {result.analysisId}
      </p>
    </div>
  );
}

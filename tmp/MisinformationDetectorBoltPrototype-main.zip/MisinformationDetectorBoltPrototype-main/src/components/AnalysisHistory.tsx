import { Analysis } from '@/types';
import { formatDate, getCredibilityColor, truncateText } from '@/utils/formatters';
import { BarChart3 } from 'lucide-react';

interface AnalysisHistoryProps {
  analyses: Analysis[];
  isLoading: boolean;
}

export function AnalysisHistory({ analyses, isLoading }: AnalysisHistoryProps) {
  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading history...</p>
      </div>
    );
  }

  if (analyses.length === 0) {
    return (
      <div className="text-center py-12">
        <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No analyses yet. Submit some content to get started!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {analyses.map((analysis) => (
        <div
          key={analysis.id}
          className="p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              {analysis.text_input && (
                <p className="text-sm text-gray-600 font-medium">Text Analysis</p>
              )}
              {analysis.url_input && (
                <p className="text-sm text-gray-600 font-medium">URL Analysis</p>
              )}
              <p className="text-sm text-gray-700 mt-1">
                {analysis.text_input
                  ? truncateText(analysis.text_input)
                  : analysis.url_input}
              </p>
            </div>
            <div className="text-right ml-4">
              <p
                className={`text-lg font-bold ${getCredibilityColor(
                  analysis.credibility_score
                )}`}
              >
                {analysis.credibility_score}%
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {formatDate(analysis.created_at)}
              </p>
            </div>
          </div>

          {analysis.reasoning && (
            <p className="text-sm text-gray-600 mt-3 mb-3">
              {truncateText(analysis.reasoning, 150)}
            </p>
          )}

          {analysis.flags && analysis.flags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {analysis.flags.slice(0, 3).map((flag, idx) => (
                <span
                  key={idx}
                  className="inline-block px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded"
                >
                  {flag}
                </span>
              ))}
              {analysis.flags.length > 3 && (
                <span className="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded">
                  +{analysis.flags.length - 3} more
                </span>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

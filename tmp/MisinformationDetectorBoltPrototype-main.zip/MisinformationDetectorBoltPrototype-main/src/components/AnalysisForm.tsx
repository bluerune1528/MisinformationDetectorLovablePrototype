import { useState } from 'react';
import { AlertCircle } from 'lucide-react';

interface AnalysisFormProps {
  onSubmit: (data: { text?: string; url?: string }) => Promise<void>;
  isLoading: boolean;
}

export function AnalysisForm({ onSubmit, isLoading }: AnalysisFormProps) {
  const [activeTab, setActiveTab] = useState<'text' | 'url'>('text');
  const [textInput, setTextInput] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [error, setError] = useState('');

  const handleTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!textInput.trim()) {
      setError('Please enter some text to analyze');
      return;
    }

    if (textInput.trim().length < 10) {
      setError('Text must be at least 10 characters long');
      return;
    }

    try {
      await onSubmit({ text: textInput });
      setTextInput('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!urlInput.trim()) {
      setError('Please enter a URL to analyze');
      return;
    }

    try {
      new URL(urlInput);
    } catch {
      setError('Please enter a valid URL');
      return;
    }

    try {
      await onSubmit({ url: urlInput });
      setUrlInput('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-4">
          <button
            onClick={() => {
              setActiveTab('text');
              setError('');
            }}
            className={`py-3 px-4 font-medium border-b-2 transition-colors ${
              activeTab === 'text'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Analyze Text
          </button>
          <button
            onClick={() => {
              setActiveTab('url');
              setError('');
            }}
            className={`py-3 px-4 font-medium border-b-2 transition-colors ${
              activeTab === 'url'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Analyze URL
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {activeTab === 'text' ? (
        <form onSubmit={handleTextSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Text to Analyze
            </label>
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Paste the text you want to check for misinformation..."
              className="w-full h-40 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              disabled={isLoading}
            />
            <p className="mt-2 text-sm text-gray-500">
              {textInput.length} characters
            </p>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? 'Analyzing...' : 'Analyze Text'}
          </button>
        </form>
      ) : (
        <form onSubmit={handleUrlSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              URL to Analyze
            </label>
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Enter a URL (e.g., https://example.com/article)"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isLoading}
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? 'Analyzing...' : 'Analyze URL'}
          </button>
        </form>
      )}
    </div>
  );
}

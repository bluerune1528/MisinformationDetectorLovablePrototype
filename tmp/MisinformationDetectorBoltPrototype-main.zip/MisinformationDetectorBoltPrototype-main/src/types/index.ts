export interface Analysis {
  id: string;
  text_input: string | null;
  url_input: string | null;
  extracted_text: string | null;
  credibility_score: number;
  reasoning: string;
  flags: string[];
  source_authority: number | null;
  created_at: string;
}

export interface AnalysisRequest {
  text?: string;
  url?: string;
}

export interface AnalysisResponse {
  credibilityScore: number;
  reasoning: string;
  flags: string[];
  sourceAuthority?: number;
  analysisId: string;
}

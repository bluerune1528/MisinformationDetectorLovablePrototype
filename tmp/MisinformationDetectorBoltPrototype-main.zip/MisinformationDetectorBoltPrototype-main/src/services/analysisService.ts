import { supabase } from '@/lib/supabase';
import { AnalysisRequest, AnalysisResponse } from '@/types';

export async function analyzeContent(request: AnalysisRequest): Promise<AnalysisResponse> {
  const { data, error } = await supabase.functions.invoke('analyze-content', {
    body: request,
  });

  if (error) {
    throw new Error(`Analysis failed: ${error.message}`);
  }

  return data as AnalysisResponse;
}

export async function getAnalysisHistory(limit: number = 20) {
  const { data, error } = await supabase
    .from('analyses')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    throw new Error(`Failed to fetch history: ${error.message}`);
  }

  return data;
}

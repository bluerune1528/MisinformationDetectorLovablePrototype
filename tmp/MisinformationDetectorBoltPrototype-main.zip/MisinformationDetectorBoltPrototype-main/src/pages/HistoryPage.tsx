import { useState, useEffect } from 'react';
import { AnalysisHistory } from '@/components/AnalysisHistory';
import { getAnalysisHistory } from '@/services/analysisService';
import { Analysis } from '@/types';

export function HistoryPage() {
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const data = await getAnalysisHistory(50);
        setAnalyses(data || []);
      } catch (err) {
        console.error('Failed to load history:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Analysis History</h2>
          <p className="text-gray-600">
            View all analyses performed on this platform
          </p>
        </div>

        <AnalysisHistory analyses={analyses} isLoading={isLoading} />
      </div>
    </main>
  );
}

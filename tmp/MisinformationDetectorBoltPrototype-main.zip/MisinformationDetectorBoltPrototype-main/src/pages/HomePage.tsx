import { useState } from 'react';
import { AnalysisForm } from '@/components/AnalysisForm';
import { ResultsDisplay } from '@/components/ResultsDisplay';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { analyzeContent } from '@/services/analysisService';
import { AnalysisResponse } from '@/types';

export function HomePage() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResponse | null>(null);
  const [error, setError] = useState('');

  const handleAnalysis = async (data: { text?: string; url?: string }) => {
    setIsLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await analyzeContent(data);
      setResult(response);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'An error occurred during analysis. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Detect Misinformation
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Paste text or a URL to check for potential misinformation, bias, and credibility issues using AI analysis.
          </p>
        </div>

        {error && (
          <div className="max-w-2xl mx-auto mb-8 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {isLoading ? (
          <LoadingSpinner />
        ) : result ? (
          <div className="space-y-8">
            <ResultsDisplay result={result} />
            <div className="text-center">
              <button
                onClick={() => setResult(null)}
                className="px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                Analyze Another
              </button>
            </div>
          </div>
        ) : (
          <AnalysisForm onSubmit={handleAnalysis} isLoading={isLoading} />
        )}
      </div>
    </main>
  );
}

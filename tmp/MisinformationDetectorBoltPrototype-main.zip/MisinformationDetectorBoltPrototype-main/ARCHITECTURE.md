# Technical Architecture Document

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER BROWSER                              │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │            React Single Page Application                 │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐    │   │
│  │  │ HomePage     │  │ HistoryPage  │  │ Components  │    │   │
│  │  │ - Form input │  │ - Load       │  │ - Routing   │    │   │
│  │  │ - Display    │  │ - Display    │  │ - State     │    │   │
│  │  └──────────────┘  └──────────────┘  └─────────────┘    │   │
│  │                         ↓                                  │   │
│  │        analysisService.ts (API calls)                    │   │
│  └──────────────────────────────────────────────────────────┘   │
│                          ↓ HTTP                                  │
└─────────────────────────────────────────────────────────────────┘
                          ↓
        ┌─────────────────────────────────────┐
        │   SUPABASE (Backend as a Service)   │
        │                                      │
        │  ┌──────────────────────────────┐   │
        │  │  Edge Functions (Deno)       │   │
        │  │                              │   │
        │  │  /analyze-content            │   │
        │  │  ├─ Extract URL text         │   │
        │  │  ├─ Calculate score          │   │
        │  │  ├─ Generate flags           │   │
        │  │  └─ Save to database         │   │
        │  └──────────────────────────────┘   │
        │                ↓                     │
        │  ┌──────────────────────────────┐   │
        │  │  PostgreSQL Database         │   │
        │  │                              │   │
        │  │  analyses table:             │   │
        │  │  - id (UUID)                 │   │
        │  │  - text_input                │   │
        │  │  - url_input                 │   │
        │  │  - credibility_score         │   │
        │  │  - reasoning                 │   │
        │  │  - flags                     │   │
        │  │  - source_authority          │   │
        │  │  - created_at                │   │
        │  └──────────────────────────────┘   │
        │                                      │
        └─────────────────────────────────────┘
```

---

## Component Hierarchy

```
App
├── Router
│   ├── Route / → HomePage
│   │   ├── Header
│   │   ├── AnalysisForm (user input)
│   │   └── ResultsDisplay (after analysis)
│   │
│   └── Route /history → HistoryPage
│       ├── Header
│       └── AnalysisHistory (list of analyses)
```

---

## Data Flow for Text Analysis

```
User Types Text
    ↓
Click "Analyze Text"
    ↓
AnalysisForm.onSubmit()
    ↓
HomePage state: setIsLoading(true)
    ↓
Call: analysisService.analyzeContent({ text: "..." })
    ↓
POST /functions/v1/analyze-content
{
  text: "user input here"
}
    ↓
Edge Function: analyze-content/index.ts
├─ Receive text
├─ Calculate credibility score (heuristics)
├─ Generate warning flags
├─ Save to PostgreSQL
└─ Return response
    ↓
Response JSON:
{
  credibilityScore: 65,
  reasoning: "...",
  flags: ["flag1", "flag2"],
  sourceAuthority: null,
  analysisId: "uuid"
}
    ↓
HomePage state: setResult(response)
    ↓
ResultsDisplay renders results
    ↓
User sees analysis!
```

---

## Data Flow for URL Analysis

```
User Pastes URL
    ↓
Click "Analyze URL"
    ↓
AnalysisForm.onSubmit()
    ↓
POST /functions/v1/analyze-content
{
  url: "https://example.com/article"
}
    ↓
Edge Function: analyze-content/index.ts
├─ Validate URL format
├─ Fetch URL content using fetch()
├─ Extract text from HTML
│  └─ Remove HTML tags, clean up
├─ Extract domain from URL
├─ Calculate source authority score
├─ Calculate credibility score (heuristics)
├─ Generate warning flags
├─ Save to PostgreSQL
└─ Return response
    ↓
Response JSON:
{
  credibilityScore: 72,
  reasoning: "...",
  flags: [],
  sourceAuthority: 85,
  analysisId: "uuid"
}
    ↓
ResultsDisplay renders with source authority
    ↓
User sees analysis!
```

---

## Database Schema

### analyses Table

```sql
CREATE TABLE analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Input data
  text_input text,              -- User's text claim (nullable)
  url_input text,               -- User's URL (nullable)
  extracted_text text,          -- Text extracted from URL (nullable)

  -- Analysis results
  credibility_score integer,    -- 0-100
  reasoning text,               -- AI explanation
  flags text[],                 -- Array of warning flags
  source_authority integer,     -- 0-100 for URLs (nullable)

  -- Metadata
  created_at timestamptz DEFAULT now()
);

-- Index for fast queries by date
CREATE INDEX idx_analyses_created_at ON analyses(created_at DESC);
```

---

## Edge Function (analyze-content)

### Input Format
```typescript
{
  text?: string;    // User's claim to analyze
  url?: string;     // User's URL to analyze
}
```

### Processing Steps

1. **Validate Input**
   - Check text or url provided
   - Return 400 if neither

2. **Extract Text** (if URL)
   ```typescript
   - Fetch URL using fetch()
   - Parse HTML
   - Remove tags and clean
   - Limit to first 2000 chars
   ```

3. **Calculate Credibility Score**
   ```typescript
   - Start with base: 50
   - Check for excessive caps: -10
   - Check for exclamation marks: -8
   - Check for suspicious phrases: -15
   - Check for URLs/citations: +10
   - Final: clamp 0-100
   ```

4. **Generate Flags**
   ```typescript
   - Too many exclamation marks? → flag
   - All caps text? → flag
   - Emotional language? → flag
   - Conspiracy keywords? → flag
   - Return top 3 flags
   ```

5. **Calculate Domain Authority** (if URL)
   ```typescript
   - Check against known good/bad domains
   - Check if HTTPS
   - Return 0-100 score
   ```

6. **Save to Database**
   ```typescript
   - POST /rest/v1/analyses
   - Include all analysis results
   ```

7. **Return Response**
   ```json
   {
     "credibilityScore": 65,
     "reasoning": "...",
     "flags": ["flag1"],
     "sourceAuthority": 85,
     "analysisId": "uuid-123"
   }
   ```

### Output Format
```typescript
{
  credibilityScore: number;     // 0-100
  reasoning: string;            // Explanation
  flags: string[];              // Warning flags
  sourceAuthority?: number;     // 0-100 for URLs
  analysisId: string;           // UUID for tracking
}
```

---

## API Endpoints

### POST /functions/v1/analyze-content

**Purpose:** Analyze text or URL for misinformation

**Request:**
```bash
curl -X POST https://project.supabase.co/functions/v1/analyze-content \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "This is a claim to check"
  }'
```

**Response:**
```json
{
  "credibilityScore": 65,
  "reasoning": "Content shows mixed signals...",
  "flags": ["Strong emotional language"],
  "sourceAuthority": null,
  "analysisId": "550e8400-e29b-41d4-a716-446655440000"
}
```

---

### GET /rest/v1/analyses

**Purpose:** Fetch analysis history

**Request:**
```bash
curl https://project.supabase.co/rest/v1/analyses \
  -H "apikey: YOUR_ANON_KEY" \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

**Query Parameters:**
- `select=*` - Select all columns
- `order=created_at.desc` - Order by newest first
- `limit=50` - Get 50 results

**Response:**
```json
[
  {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "text_input": "This is a claim",
    "url_input": null,
    "extracted_text": null,
    "credibility_score": 65,
    "reasoning": "...",
    "flags": ["Strong emotional language"],
    "source_authority": null,
    "created_at": "2024-01-15T10:30:00Z"
  }
]
```

---

## Credibility Scoring Algorithm

### Scoring Factors

| Factor | Weight | Range | Examples |
|--------|--------|-------|----------|
| Language tone | 30% | -30 to +10 | Caps, exclamation marks |
| Content quality | 30% | -20 to +10 | Citations, sources, data |
| Red flags | 20% | -30 to 0 | Conspiracy, emotional |
| Domain authority | 20% | -40 to +40 | HTTPS, known sources |

### Example Calculation

**Claim:** "You won't BELIEVE what doctors are hiding!!!"

```
Base score: 50

Language analysis:
- "You won't believe" phrase: -15
- BELIEVE in caps: -10
- 3 exclamation marks: -8
- No citations: -5
Subtotal: 50 - 15 - 10 - 8 - 5 = 12

Final Score: 12 (Likely Misinformation)

Flags Generated:
1. "Excessive exclamation marks detected"
2. "Strong emotional language detected"
3. "Conspiracy-related keywords detected"

Reasoning: "This content shows multiple indicators commonly
found in misinformation. We strongly recommend verifying claims
through trusted sources before sharing."
```

---

## Technology Stack Details

### Frontend
- **React 18** - Latest React features
- **TypeScript** - Type safety and IDE support
- **Vite** - Fast build tool (< 1 second HMR)
- **React Router 6** - Client-side navigation
- **Tailwind CSS** - Utility-first CSS
- **Lucide React** - Icon library

### Backend
- **Supabase** - Backend as a Service (Firebase alternative)
- **PostgreSQL 14+** - Relational database
- **Deno** - Runtime for Edge Functions (TypeScript out of box)

### Deployment
- **Vercel** - Frontend hosting (recommended for students)
- **Supabase Hosting** - Backend (included in Supabase)

---

## Code Organization

```
src/
├── components/          # Reusable React components
│   ├── *.tsx
│   └── Each component handles ONE thing
├── pages/              # Full-page components
│   ├── HomePage.tsx
│   └── HistoryPage.tsx
├── services/           # API calls and queries
│   └── analysisService.ts
├── types/              # TypeScript interfaces
│   └── index.ts
├── utils/              # Helper functions
│   └── formatters.ts
├── lib/                # Library setup
│   └── supabase.ts
├── App.tsx             # Main app with routing
├── main.tsx            # React DOM render
└── index.css           # Global styles
```

---

## Common Tasks

### Adding a New Component

1. Create file in `src/components/MyComponent.tsx`
2. Export component function
3. Import in page or parent component
4. Add to JSX

### Adding a Database Query

1. Add function to `src/services/analysisService.ts`
2. Use `supabase.from('table').select(...)` pattern
3. Handle errors and null checks
4. Return typed data

### Deploying Edge Function

```bash
supabase functions deploy analyze-content
```

Or use the tool provided in development.

### Deploying Frontend

```bash
npm run build
# Then deploy dist/ folder to Vercel
```

---

## Performance Considerations

### Frontend
- Components are lazy-loaded via React Router
- Tailwind CSS is tree-shaken for production
- Images are optimized
- Build size ~100KB gzipped

### Backend
- Database queries are indexed for speed
- Edge Functions are cached by Supabase CDN
- No N+1 query problems (simple queries)

### Analysis Speed
- Text analysis: <100ms
- URL fetch + analysis: 1-2 seconds
- Database save: <100ms
- Total: 1-2 seconds per analysis

---

## Error Handling

### Frontend
- Try-catch blocks around API calls
- User-friendly error messages
- Loading states prevent double-submit
- Network error recovery

### Backend
- Input validation
- Error responses with status codes
- Detailed console logging
- Graceful fallbacks

---

## Security Considerations

### Frontend
- No sensitive data stored in localStorage
- No inline scripts
- HTTPS only (enforced by Supabase)

### Backend
- Supabase auth tokens used for API calls
- No sensitive data logged
- Input validation on all endpoints
- SQL injection prevention (Supabase handles this)

### Database
- Public read access (no sensitive data)
- No authentication required (public tool)
- Basic data protection (no PII stored)

---

## Monitoring & Debugging

### Check API Calls
1. Open DevTools (F12)
2. Network tab
3. Filter by "analyze-content"
4. Check request/response

### Check Database
1. Go to Supabase dashboard
2. SQL Editor
3. Run: `SELECT * FROM analyses ORDER BY created_at DESC LIMIT 10`

### Check Edge Function Logs
1. Supabase dashboard
2. Edge Functions → analyze-content
3. View logs

---

## Future Improvements

### Phase 2: ML Models
- Integrate Hugging Face free API
- Use zero-shot classification
- Sentiment analysis

### Phase 3: Fact-Checking
- Integrate fact-checking databases
- Wikipedia integration
- Snopes.com API

### Phase 4: User Features
- User accounts
- Save favorite analyses
- Share results
- Bookmarking

### Phase 5: Expansion
- Image analysis
- Video analysis
- Multi-language support
- Browser extension

---

This architecture is simple, scalable, and perfect for a college project!

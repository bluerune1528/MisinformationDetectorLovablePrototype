# Team Work Division Guide

This document explains how the 5-person team should divide the work for this college project.

## Quick Summary

| Student | Role | Main Files | Timeline |
|---------|------|-----------|----------|
| 1 | Frontend Components | `src/components/*` | Days 1-2 |
| 2 | Frontend Logic | `src/pages/*`, routing | Days 2-3 |
| 3 | Database | `supabase/`, Supabase setup | Days 1-2 |
| 4 | Analysis Algorithm | `supabase/functions/analyze-content/` | Days 2-4 |
| 5 | Integration & Testing | Test everything, deployment | Days 4-6 |

---

## Student 1: Frontend Components Developer

### What You'll Build
Create all React components that users interact with.

### Files to Create/Modify
```
src/components/
├── AnalysisForm.tsx      (START HERE)
├── ResultsDisplay.tsx
├── AnalysisHistory.tsx
├── Header.tsx
└── LoadingSpinner.tsx
```

### Your Tasks (In Order)

1. **Create AnalysisForm.tsx** (Day 1 morning)
   - Input form with two tabs: "Analyze Text" and "Analyze URL"
   - Text textarea for claims
   - URL input for websites
   - Submit buttons
   - Form validation feedback
   - Error messages
   - Styling with Tailwind CSS

2. **Create Header.tsx** (Day 1 afternoon)
   - Logo with icon
   - Navigation links (Analyze, History)
   - Clean, simple header bar

3. **Create ResultsDisplay.tsx** (Day 1 evening)
   - Display credibility score (0-100)
   - Color-coded (red/yellow/green)
   - Show reasoning text
   - List warning flags
   - Display source authority score
   - Make it visually clear and easy to understand

4. **Create AnalysisHistory.tsx** (Day 2 morning)
   - List of past analyses
   - Show input text/URL
   - Show credibility score
   - Show date/time
   - Truncate long text
   - Display flags as tags

5. **Create LoadingSpinner.tsx** (Day 2 afternoon)
   - Simple spinning loader animation
   - "Analyzing..." message
   - Show while processing

### Tips for Student 1
- Start with AnalysisForm - it's the most important
- Use Tailwind CSS for styling (already installed)
- Use lucide-react for icons
- Check existing components for patterns
- Don't worry about functionality - just UI
- Make it mobile-responsive

### Testing Your Work
- Run `npm run dev`
- Check all components render correctly
- Test form inputs work
- Verify styling looks good on phone/tablet/desktop

---

## Student 2: Frontend Logic & Pages

### What You'll Build
Connect components together, handle page routing, manage user interactions.

### Files to Create/Modify
```
src/
├── App.tsx              (ALREADY DONE - don't change)
├── pages/
│   ├── HomePage.tsx     (START HERE)
│   └── HistoryPage.tsx
└── main.tsx
```

### Your Tasks (In Order)

1. **Create HomePage.tsx** (Day 2 morning)
   - Import AnalysisForm component
   - Import ResultsDisplay component
   - Import LoadingSpinner component
   - State management for loading, results, errors
   - Call analysisService.analyzeContent when form submitted
   - Display spinner while loading
   - Display results when complete
   - Handle errors gracefully
   - "Analyze Another" button to reset

2. **Create HistoryPage.tsx** (Day 2 afternoon)
   - Import AnalysisHistory component
   - Fetch analyses on page load using analysisService
   - Pass data to AnalysisHistory component
   - Handle loading state
   - Handle empty state (no analyses yet)

3. **Verify Routing** (Day 3 morning)
   - Check `/` route shows HomePage
   - Check `/history` route shows HistoryPage
   - Test navigation links work
   - Test page switching is smooth

### Tips for Student 2
- Focus on React hooks: `useState`, `useEffect`
- Use analysisService that Student 4 provides
- Handle loading states properly
- Handle error messages
- Keep components simple

### Testing Your Work
- Run `npm run dev`
- Click between Analyze and History pages
- Submit a form and see results display
- Go to history page and see saved analyses
- Check all navigation works

---

## Student 3: Database & Supabase Setup

### What You'll Build
Database schema, Supabase configuration, data queries.

### Files & Tasks

1. **Verify Database Setup** (Day 1 morning) ✓ ALREADY DONE
   - Check `supabase/migrations/001_create_analyses_table.sql` exists
   - Table `analyses` created with correct columns
   - Indexes created for performance

2. **Create supabase.ts Client** (Day 1 midday) ✓ ALREADY DONE
   - Import Supabase client library
   - Initialize with environment variables
   - Export singleton instance

3. **Create analysisService.ts** (Day 1 afternoon) ✓ ALREADY DONE
   - `analyzeContent()` function - calls Edge Function
   - `getAnalysisHistory()` function - fetches analyses from database

4. **Testing Database** (Day 2 morning)
   - Verify Supabase connection works
   - Test inserting sample data
   - Test querying data back
   - Verify indexes are working
   - Check query performance

### Your Database Structure
```sql
analyses table:
- id (UUID, primary key)
- text_input (text, nullable)
- url_input (text, nullable)
- extracted_text (text, nullable)
- credibility_score (0-100)
- reasoning (text explanation)
- flags (array of strings)
- source_authority (0-100, nullable)
- created_at (timestamp)
```

### Tips for Student 3
- Don't modify database after creation (Student 5 can help)
- Keep queries simple
- Use Supabase dashboard to check data
- Test with sample data
- Document how to set up Supabase for new machines

### Testing Your Work
- Run `npm run dev`
- Check Supabase console shows empty table
- Manually insert a test record
- Query it back and verify data
- Check indexes are created

---

## Student 4: Analysis Algorithm & Edge Function

### What You'll Build
The AI analysis engine that calculates credibility scores and flags.

### Files to Create/Modify
```
supabase/functions/
└── analyze-content/
    └── index.ts  (START HERE)
```

### Your Tasks (In Order)

1. **Understand the Algorithm** (Day 1)
   - Read through the existing Edge Function code
   - Understand how scoring works
   - Understand flags detection
   - Understand URL extraction

2. **Test Edge Function Locally** (Day 2 morning)
   - Deploy function: `npm run deploy` (or use Supabase CLI)
   - Call it with test data
   - Verify it returns correct format
   - Check database is being updated

3. **Improve Analysis Algorithm** (Days 2-3)
   - Add more pattern detection
   - Fine-tune scoring weights
   - Add more warning flags
   - Handle edge cases
   - Test with real claims

4. **Test with Various Inputs** (Day 3-4)
   - Text that should be high credibility (70+)
   - Text that should be low credibility (0-30)
   - Text that should be uncertain (40-60)
   - Various URLs
   - Edge cases

### Example Inputs to Test

**High Credibility** (should score 70+):
- "According to a recent study published in Nature, climate change is accelerating."
- "The Centers for Disease Control recommends getting vaccinated before traveling internationally."

**Low Credibility** (should score 0-30):
- "You won't BELIEVE what doctors don't want you to know!!!"
- "This ONE TRICK will cure cancer!!!"

**Uncertain** (should score 40-60):
- Mixed information with both good and bad signals

### Tips for Student 4
- Start simple, add complexity later
- Test frequently
- Comment your code
- Handle errors properly
- Be careful with API calls (they use quota)

### Testing Your Work
- Submit various test claims
- Check scores make sense
- Verify flags are accurate
- Check database saves results
- Monitor for errors

---

## Student 5: Integration, Testing & Deployment

### What You'll Build
Make everything work together, test the whole system, deploy to internet.

### Your Tasks (In Order)

1. **End-to-End Testing** (Day 4)
   - Test the complete flow: User input → Analysis → Results → Database
   - Test history page shows saved analyses
   - Test navigation between pages
   - Test error handling
   - Test loading states

2. **Performance Testing** (Day 4 afternoon)
   - How fast is analysis processing? (Should be <3 seconds)
   - How fast does history page load?
   - Any UI lag?
   - Mobile responsiveness?

3. **Bug Fixes** (Day 5)
   - Collect bugs from testing
   - Prioritize by severity
   - Fix bugs (with help from relevant student)
   - Retest fixes

4. **Deployment** (Day 5)
   - Deploy to Vercel (easiest for students)
   - Or GitHub Pages / Netlify
   - Test deployed version works
   - Get live URL

5. **Documentation** (Day 6)
   - Write setup guide for new developers
   - Document team work division
   - List remaining improvements
   - Create deployment guide

### Testing Checklist

- [ ] Text analysis works and saves to database
- [ ] URL analysis works and saves to database
- [ ] History page shows all analyses
- [ ] Credibility scores are reasonable
- [ ] Warning flags are accurate
- [ ] Loading spinner shows while processing
- [ ] Errors handled gracefully
- [ ] Mobile responsive on phones
- [ ] Navigation works smoothly
- [ ] App works after page refresh
- [ ] No console errors

### Tips for Student 5
- Use a spreadsheet to track bugs
- Test on both desktop and phone
- Try to break things
- Document issues clearly
- Help other students debug
- Keep deployment documentation simple

### Deployment Checklist
- [ ] Environment variables configured
- [ ] Build completes without errors
- [ ] All dependencies installed
- [ ] Supabase connection working
- [ ] Edge Function deployed and accessible
- [ ] Database has required tables
- [ ] Site is accessible from internet
- [ ] No sensitive data exposed

---

## Communication & Collaboration

### Daily Standup (10 minutes)
- What did I complete yesterday?
- What am I working on today?
- What blockers do I have?

### File Ownership
- **Student 1**: All files in `src/components/`
- **Student 2**: All files in `src/pages/`
- **Student 3**: All files in `supabase/` (database, queries)
- **Student 4**: `supabase/functions/analyze-content/` (algorithm)
- **Student 5**: `src/lib/`, `src/services/`, `src/utils/`, and everything else

### Code Review Process
1. Before committing, test your changes
2. Write clear commit messages
3. Review others' code before merging
4. Ask questions if unsure
5. Help debug each other's issues

### Git Workflow
```bash
# Update your local repo
git pull origin main

# Create a feature branch
git checkout -b feature/student1-components

# Make changes and commit
git add .
git commit -m "Add AnalysisForm component"

# Push to GitHub
git push origin feature/student1-components

# Create Pull Request on GitHub
# Other students review
# Merge when approved
```

---

## Timeline Summary

**Week 1:**
- Days 1-2: Students 1, 3, 4 work in parallel
- Days 2-3: Students 2 works on pages
- Days 3-4: Student 4 refines algorithm

**Week 2:**
- Days 4-5: Student 5 does integration testing
- Day 5: Deploy to production
- Day 6: Documentation and cleanup

---

## Potential Issues & How to Handle Them

### "My changes broke the app"
- Don't panic, revert your changes with `git revert`
- Test locally before pushing
- Ask for help debugging

### "Supabase isn't responding"
- Check internet connection
- Check .env file has correct credentials
- Restart dev server
- Contact Supabase support if down

### "Edge Function returns error"
- Check function code for syntax errors
- Check console logs
- Verify Supabase environment variables
- Test with simple inputs first

### "Merge conflicts"
- Pull latest from main
- Resolve conflicts (ask for help)
- Test after merging
- Push resolved changes

---

## Success Criteria

Your project is successful when:
✅ Text analysis works and saves results
✅ URL analysis works and saves results
✅ History page shows all analyses
✅ Credibility scores make sense
✅ App is deployed and accessible online
✅ No major bugs or crashes
✅ Code is reasonably organized
✅ Documentation is clear

---

## Getting Help

- **Questions about components?** Ask Student 1
- **Questions about pages/routing?** Ask Student 2
- **Questions about database?** Ask Student 3
- **Questions about analysis algorithm?** Ask Student 4
- **Questions about deployment?** Ask Student 5
- **General questions?** Ask any student or your professor

---

Good luck! 🚀
